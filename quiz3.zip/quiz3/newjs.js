let Counter_value = 0
const counter = document.querySelector(".counter-cont")
Counter_value.toFixed()
//i know my problem is Counter_value not int
function Increase(Counter_value) {
    Counter_value++
    console.log(Counter_value)
    counter.textContent = Counter_value
}

function Reset(Counter_value) {
    Counter_value = 0
    console.log(Counter_value)
    counter.textContent = Counter_value

}

function Decrese(Counter_value) {
    Counter_value--
    console.log(Counter_value)
    counter.textContent = Counter_value
    
}